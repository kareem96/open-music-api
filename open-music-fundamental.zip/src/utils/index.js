const mapDBToModel = ({
    id, title, year, genre, performer, duration,
}) => ({
    id, title, year, genre, performer, duration,
});

module.exports = { mapDBToModel};